from django.forms.forms import Form
from django.shortcuts import redirect,render,HttpResponse,get_object_or_404

import article
from .forms import ArticleForm,Article
from django.contrib import messages


# Create your views here.
def index(request):
    context = {
        "nu1": "Sayfaya Tam erişim için lütfen giriş yapın...",
    }
    return render(request, "index.html",context)

def about(request):
    return render(request, "about.html")

def dashboard(request):
    articles = Article.objects.filter(author = request.user)
    context = {
        "articles":articles
    }
    return render(request,"dashboard.html",context)

def addArticle(request):
    form = ArticleForm(request.POST or None)

    if form.is_valid():
        article = form.save(commit=False)
        article.author = request.user
        article.save()
        messages.success(request,"Makale Başarıyla Oluşturuldu.")
        return redirect("index")
    return render(request,"addarticle.html",{"form" :form})
def detail(request,id):
    article = get_object_or_404(Article,id = id)
    return render(request,"detail.html",{"article":article})